import React from 'react';
import './App.css';
import Spacex from './component/spacex/spacex';


function App() {
  return (
    <div className="App">
        <Spacex />
    </div>
  );
}

export default App;
